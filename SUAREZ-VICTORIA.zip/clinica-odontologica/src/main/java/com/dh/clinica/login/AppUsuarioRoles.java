package com.dh.clinica.login;

public enum AppUsuarioRoles {
    ROLE_USER, ROLE_ADMIN
}
